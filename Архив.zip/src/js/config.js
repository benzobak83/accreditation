const CONVERTE_URL = 'http://localhost/benzospell/server/converte.php' 

export {CONVERTE_URL}